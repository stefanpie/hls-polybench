#pragma once
#include <cmath>


extern "C" {
void kernel_jacobi_1d(
			    
			    double A[ 400 + 0],
			    double B[ 400 + 0]);
}