#pragma once
#include <cmath>


extern "C" {
void kernel_floyd_warshall(
			   int path[ 500 + 0][500 + 0]);
}