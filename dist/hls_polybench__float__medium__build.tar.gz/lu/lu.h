#pragma once
#include <cmath>


extern "C" {
void kernel_lu(
	       double A[ 400 + 0][400 + 0]);
}