#pragma once
#include <cmath>


extern "C" {
void kernel_floyd_warshall(
			   int path[ 60 + 0][60 + 0]);
}