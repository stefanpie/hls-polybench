#pragma once
#include <cmath>


extern "C" {
void kernel_adi( 
		double u[ 20 + 0][20 + 0],
		double v[ 20 + 0][20 + 0],
		double p[ 20 + 0][20 + 0],
		double q[ 20 + 0][20 + 0]);
}