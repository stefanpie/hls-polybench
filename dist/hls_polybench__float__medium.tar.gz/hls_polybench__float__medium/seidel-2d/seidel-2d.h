#pragma once
#include <cmath>


extern "C" {
void kernel_seidel_2d(
		      
		      double A[ 400 + 0][400 + 0]);
}