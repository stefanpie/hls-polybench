#pragma once
#include <cmath>


extern "C" {
void kernel_lu(
	       double A[ 40 + 0][40 + 0]);
}