#pragma once
#include <cmath>


extern "C" {
void kernel_cholesky(
		     double A[ 40 + 0][40 + 0]);
}