#pragma once
#include <cmath>


extern "C" {
void kernel_deriche(  float alpha,
       float imgIn[ 64 + 0][64 + 0],
       float imgOut[ 64 + 0][64 + 0],
       float y1[ 64 + 0][64 + 0],
       float y2[ 64 + 0][64 + 0]);
}