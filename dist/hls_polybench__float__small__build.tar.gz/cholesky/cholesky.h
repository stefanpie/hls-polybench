#pragma once
#include <cmath>


extern "C" {
void kernel_cholesky(
		     double A[ 120 + 0][120 + 0]);
}