#pragma once
#include <cmath>


extern "C" {
void kernel_lu(
	       double A[ 120 + 0][120 + 0]);
}