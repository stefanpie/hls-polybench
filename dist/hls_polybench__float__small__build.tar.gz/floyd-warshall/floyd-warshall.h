#pragma once
#include <cmath>


extern "C" {
void kernel_floyd_warshall(
			   int path[ 180 + 0][180 + 0]);
}