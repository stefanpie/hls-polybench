#pragma once
#include "ap_fixed.h"
#include "hls_math.h"

typedef ap_fixed<32,16> t_ap_fixed;

extern "C" {
void kernel_deriche(  t_ap_fixed alpha,
       t_ap_fixed imgIn[ 64 + 0][64 + 0],
       t_ap_fixed imgOut[ 64 + 0][64 + 0],
       t_ap_fixed y1[ 64 + 0][64 + 0],
       t_ap_fixed y2[ 64 + 0][64 + 0]);
}