#include "adi.h"


#include "ap_fixed.h"
#include "hls_math.h"


void kernel_adi( 
		t_ap_fixed u[ 20 + 0][20 + 0],
		t_ap_fixed v[ 20 + 0][20 + 0],
		t_ap_fixed p[ 20 + 0][20 + 0],
		t_ap_fixed q[ 20 + 0][20 + 0])
{
  #pragma HLS top name=kernel_adi

    const int n = 20;
    const int tsteps = 20;

  int t, i, j;
  t_ap_fixed DX, DY, DT;
  t_ap_fixed B1, B2;
  t_ap_fixed mul1, mul2;
  t_ap_fixed a, b, c, d, e, f;
  t_ap_fixed pm1, qm1, pj, qj, wn, wj;


  DX = (t_ap_fixed(1.0))/(t_ap_fixed)n;
  DY = (t_ap_fixed(1.0))/(t_ap_fixed)n;
  DT = (t_ap_fixed(1.0))/(t_ap_fixed)tsteps;
  B1 = (t_ap_fixed(2.0));
  B2 = (t_ap_fixed(1.0));
  mul1 = B1 * DT / (DX * DX);
  mul2 = B2 * DT / (DY * DY);

  a = -mul1 /  (t_ap_fixed(2.0));
  b = (t_ap_fixed(1.0))+mul1;
  c = a;
  d = -mul2 / (t_ap_fixed(2.0));
  e = (t_ap_fixed(1.0))+mul2;
  f = d;

 for (t=1; t<=tsteps; t++) {

    for (i=1; i<n-1; i++) {
      v[0][i] = (t_ap_fixed(1.0));
      p[i][0] = (t_ap_fixed(0.0));
      q[i][0] = v[0][i];
      pm1 = p[i][0];
      qm1 = q[i][0];
      for (j=1; j<n-1; j++) {
        pj = -c / (a*pm1+b);
        qj = (-d*u[j][i-1]+((t_ap_fixed(1.0))+(t_ap_fixed(2.0))*d)*u[j][i] - f*u[j][i+1]-a*qm1)/(a*pm1+b);
        p[i][j] = pj;
        q[i][j] = qj;
        pm1 = pj;
        qm1 = qj;
      }

      v[n-1][i] = (t_ap_fixed(1.0));
      wn = v[n-1][i];
      for (j=n-2; j>=1; j--) {
        wj = p[i][j] * wn + q[i][j];
        v[j][i] = wj;
        wn = wj;
      }
    }

    for (i=1; i<n-1; i++) {
      u[i][0] = (t_ap_fixed(1.0));
      p[i][0] = (t_ap_fixed(0.0));
      q[i][0] = u[i][0];
      pm1 = p[i][0];
      qm1 = q[i][0];
      for (j=1; j<n-1; j++) {
        pj = -f / (d*pm1+e);
        qj = (-a*v[i-1][j]+((t_ap_fixed(1.0))+(t_ap_fixed(2.0))*a)*v[i][j] - c*v[i+1][j]-d*qm1)/(d*pm1+e);
        p[i][j] = pj;
        q[i][j] = qj;
        pm1 = pj;
        qm1 = qj;
      }
      u[i][n-1] = (t_ap_fixed(1.0));
      wn = u[i][n-1];
      for (j=n-2; j>=1; j--) {
        wj = p[i][j] * wn + q[i][j];
        u[i][j] = wj;
        wn = wj;
      }
    }
  }
}