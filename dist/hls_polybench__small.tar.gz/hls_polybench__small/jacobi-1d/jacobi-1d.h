#pragma once
#include <cmath>


extern "C" {
void kernel_jacobi_1d(
			    
			    double A[ 120 + 0],
			    double B[ 120 + 0]);
}