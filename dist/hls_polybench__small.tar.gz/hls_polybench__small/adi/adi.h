#pragma once
#include <cmath>


extern "C" {
void kernel_adi( 
		double u[ 60 + 0][60 + 0],
		double v[ 60 + 0][60 + 0],
		double p[ 60 + 0][60 + 0],
		double q[ 60 + 0][60 + 0]);
}