#pragma once
#include <cmath>


extern "C" {
void kernel_deriche(  float alpha,
       float imgIn[ 192 + 0][128 + 0],
       float imgOut[ 192 + 0][128 + 0],
       float y1[ 192 + 0][128 + 0],
       float y2[ 192 + 0][128 + 0]);
}