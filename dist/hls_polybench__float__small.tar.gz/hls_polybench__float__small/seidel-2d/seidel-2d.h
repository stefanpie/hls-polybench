#pragma once
#include <cmath>


extern "C" {
void kernel_seidel_2d(
		      
		      double A[ 120 + 0][120 + 0]);
}